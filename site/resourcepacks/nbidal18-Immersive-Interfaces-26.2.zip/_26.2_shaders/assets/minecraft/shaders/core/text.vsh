#version 330

// nbidal18: port of the pack's rendertype_text.vsh to 26.2, which renamed that core shader to
// `text` and guards the fog and lightmap paths behind IS_GUI / IS_SEE_THROUGH. Without this the
// pack's container art - drawn as glyphs, which is what its lang files are for - is positioned by
// vanilla instead of by interfaces_text(), and lands offset from the panel it belongs to.
//
// Structure follows vanilla 26.2 text.vsh exactly; the only changes are calling interfaces_text()
// and using its returned position, colour and uv.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:interfaces.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

uniform sampler2D Sampler0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    Data data = interfaces_text(ProjMat, GameTime, Sampler0, Position, UV0, Color);

    gl_Position = ProjMat * ModelViewMat * vec4(data.position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = data.color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = data.color;
#endif

    texCoord0 = data.uv0;
}
