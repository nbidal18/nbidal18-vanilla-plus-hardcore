# Sources

Nothing in this pack is our artwork. It is a build-time merge of four published resource packs,
for use inside the nbidal18 Vanilla+ modpack only, plus generated item definitions and copies of
vanilla Minecraft assets. Rebuilt by `scripts\Build-3DPack.ps1` from the archives in
`5. modpack source\custom packs\nbidal18-3D\sources\`; nothing in it is edited by hand.

| Source | Author | Where | Files used here |
| --- | --- | --- | --- |
| Weskerson's 3D Items 2.5 | Weskerson | https://modrinth.com/resourcepack/weskersons-3d-items | 782 |
| Weskerson's 3D Food 1.0 | Weskerson | https://modrinth.com/resourcepack/weskersons-3d-food | 569 |
| Weskerson's Torches 1.02 (core item shader already stripped, see below) | Weskerson | https://modrinth.com/resourcepack/weskersons-torches | 128 |
| Actually 3D Blocks & Items r1.8 | Matt_Crowberry | https://modrinth.com/resourcepack/actually-3d | 1713 |
| Minecraft 26.2 (Mojang) - model and texture copies under `nbidal18/vanilla/` so the inventory draws exactly what vanilla draws | Mojang Studios | the game jar | 1605 |
| Minecraft 1.11.2 (Mojang) - the flat red bed sprite `textures/items/bed.png`, recoloured at build time into the sixteen 26.2 bed colours | Mojang Studios | the 1.11.2 game jar, kept as `sources/minecraft-1.11.2-bed.png` | 16 |
| generated here | nbidal18 | this build | 1066 |

## What the build changes

- The four packs are flattened (root assets plus any overlay that applies to resource format 88) and merged in the order the client used to apply them: Weskerson's 3D Items, then 3D Food, then Torches, then Actually 3D on top.
- Actually 3D's models for block names that Better Lanterns or Weskerson's Torches also ship are dropped, so those two keep their categories.
- Weskerson's Torches had its core item shader removed before it was archived here: on 26.2 that shader stopped every item sprite from drawing.
- Weskerson's crimson and warped hanging-sign definitions are dropped; they pointed at a hand model no pack ships.
- Weskerson's fishing rod is dropped whole - definition, hand models and textures - so the rod is vanilla in every context.
- Every `has_component minecraft:enchantments` branch in an item definition is collapsed to its unenchanted side: an enchanted tool looks exactly like the plain one (the pack ships No Enchant Glint; Weskerson's recoloured, sheen-striped enchanted models are not used).
- For every item whose inventory rendering would differ from vanilla's, a definition sends the inventory to a private copy of vanilla's own model and textures, and every other context to the 3D model. For every 3D item a source sent flat to the ground or into item frames, those contexts are sent to the 3D model, with transforms sized from its geometry where the model had none.
- Every cross-shaped plant block no source drew in the hand - saplings, grass, corals, roots, vines - gets a generated hand model under `nbidal18/hand/`: the block's own cross held upright at hand scale, with vanilla's item tint where the block is tinted. The inventory stays vanilla's flat sprite.
- The inked outlines are stripped: both packs draw a second, slightly larger, inside-out box around many models, which on 26.2 renders as a thick dark rim. An inverted box that encloses a normal box of the same model is removed; an inverted box the same size as its twin (a double-sided face) is kept.
- Beds are the one deliberate exception to "exactly vanilla in any inventory": vanilla draws a small 3D bed there, and the owner wants the flat sprite of 1.11 and earlier (decided 2026-09-04). The sixteen sprites under `nbidal18/icons/` are 1.11.2's red icon with its blanket recoloured to each bed's own 26.2 colour; hand and world still draw the 3D bed.
- Credits, title-screen art, shaders, optimiser residue and other packs' namespaces are not carried.
