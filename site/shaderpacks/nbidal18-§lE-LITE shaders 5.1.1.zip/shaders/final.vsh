#version 130
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - final.fsh
Render: Final renderer

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define USE_BASIC_SH // Sets the use of a "basic" or "generic" shader for custom dimensions, instead of the default overworld shader. This can solve some rendering issues as the shader is closer to vanilla rendering.

#ifdef USE_BASIC_SH
    #define UNKNOWN_DIM
#endif
#define FINAL_SHADER

/* Config, uniforms, ins, outs */
#include "/common/final_vertex.glsl"
